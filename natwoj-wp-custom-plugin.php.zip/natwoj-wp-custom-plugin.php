<?php 
/*
 * Plugin Name: natwoj-wp-custom-plugin
 * Plugin URI: https://wejdzonline.pl 
 * Description: My first plugin
 * Version: 1.0
 * Author: Natalia Wojcik
*/




 